from setuptools import setup

setup(name='QR_Code_Generator',
      version='0.1',
      description='A QR code generator',
      license='MIT',
      packages=['QR_Code_Generator'],
      zip_safe=False)